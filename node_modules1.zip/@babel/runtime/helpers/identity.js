function _identity(t) {
  return t;
}
module.exports = _identity, module.exports.__esModule = true, module.exports["default"] = module.exports;