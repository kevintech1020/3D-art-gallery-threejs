# `primitive`

## Installation

```sh
$ yarn add @radix-ui/primitive
# or
$ npm install @radix-ui/primitive
```

## Usage

This is an internal utility, not intended for public usage.
