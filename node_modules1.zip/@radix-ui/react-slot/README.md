# `react-slot`

## Installation

```sh
$ yarn add @radix-ui/react-slot
# or
$ npm install @radix-ui/react-slot
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/slot).
