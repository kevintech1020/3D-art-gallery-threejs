# `react-use-escape-keydown`

## Installation

```sh
$ yarn add @radix-ui/react-use-escape-keydown
# or
$ npm install @radix-ui/react-use-escape-keydown
```

## Usage

This is an internal utility, not intended for public usage.
