export declare function BakeShadows(): null;
