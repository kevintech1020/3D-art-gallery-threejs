# @react-spring/animated

Fork of [animated](https://github.com/animatedjs/animated)
