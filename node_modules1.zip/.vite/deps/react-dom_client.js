import {
  require_client
} from "./chunk-4FP5CSCV.js";
import "./chunk-FP7MBVKX.js";
import "./chunk-DRWLMN53.js";
import "./chunk-G3PMV62Z.js";
export default require_client();
//# sourceMappingURL=react-dom_client.js.map
