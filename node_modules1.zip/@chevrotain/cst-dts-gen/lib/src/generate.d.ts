import { GenerateDtsOptions } from "@chevrotain/types";
import { CstNodeTypeDefinition } from "./model";
export declare function genDts(model: CstNodeTypeDefinition[], options: Required<GenerateDtsOptions>): string;
