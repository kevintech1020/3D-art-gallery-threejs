import { Rule, GenerateDtsOptions } from "@chevrotain/types";
export declare function generateCstDts(productions: Record<string, Rule>, options?: GenerateDtsOptions): string;
