/**
 * Initializes RAPIER.
 * Has to be called and awaited before using any library methods.
 */
export declare function init(): Promise<void>;
