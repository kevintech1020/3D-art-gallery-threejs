export declare function timer<T>(func: () => T): {
    time: number;
    value: T;
};
