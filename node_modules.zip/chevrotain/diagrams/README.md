See [online docs](https://chevrotain.io/docs/guide/generating_syntax_diagrams.html).
