export const EOF_TOKEN_TYPE = 1
